# libfilesystem
cross-platform library and c++ api for filesystem-related functionality
